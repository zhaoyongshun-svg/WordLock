package com.example.wordlock;

import android.app.Activity;
import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 全屏单词锁屏页：显示在系统锁屏之上，答对才能继续使用。
 */
public class LockActivity extends Activity {
    private WordDbHelper db;
    private Word answer;
    private int wrongCount = 0;

    public static void start(Context c) {
        Intent i = new Intent(c, LockActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        c.startActivity(i);
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
            KeyguardManager km = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
            if (km != null) km.requestDismissKeyguard(this, null); // 请求解除系统锁屏
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                    | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN
                | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_lock);

        db = WordDbHelper.get(this);
        newQuiz();
        findViewById(R.id.btnSkip).setOnClickListener(v ->
                Toast.makeText(this, "答对才能解锁哦！", Toast.LENGTH_SHORT).show());
    }

    private void newQuiz() {
        answer = db.randomWord();
        if (answer == null) {
            ((TextView) findViewById(R.id.tvMeaning)).setText("词库为空
请先在主界面导入单词");
            return;
        }
        ((TextView) findViewById(R.id.tvMeaning)).setText(answer.meaning);
        ((TextView) findViewById(R.id.tvWrong)).setText(wrongCount > 0 ? "答错 " + wrongCount + " 次" : "");

        // 生成 4 个选项（含正确答案）
        List<Word> all = db.allWords();
        List<Word> options = new ArrayList<>();
        options.add(answer);
        List<Word> pool = new ArrayList<>(all);
        for (int i = pool.size() - 1; i >= 0; i--) if (pool.get(i).id == answer.id) pool.remove(i);
        Collections.shuffle(pool);
        for (int i = 0; i < Math.min(3, pool.size()); i++) options.add(pool.get(i));
        Collections.shuffle(options);

        int[] btnIds = {R.id.opt0, R.id.opt1, R.id.opt2, R.id.opt3};
        for (int i = 0; i < btnIds.length; i++) {
            Button btn = findViewById(btnIds[i]);
            if (i < options.size()) {
                final Word w = options.get(i);
                btn.setText(w.word);
                btn.setVisibility(android.view.View.VISIBLE);
                btn.setOnClickListener(v -> onAnswer(w));
            } else {
                btn.setVisibility(android.view.View.GONE);
            }
        }
    }

    private void onAnswer(Word picked) {
        if (picked.id == answer.id) {
            Toast.makeText(this, "✅ 回答正确，解锁！", Toast.LENGTH_SHORT).show();
            finish(); // 关闭锁屏页，返回正常使用
        } else {
            wrongCount++;
            Vibrator vib = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (vib != null && Build.VERSION.SDK_INT >= 26) vib.vibrate(200);
            Toast.makeText(this, "❌ 再想想：" + picked.word + " 不对", Toast.LENGTH_SHORT).show();
            newQuiz();
        }
    }

    @Override public void onBackPressed() {
        // 禁止返回键绕过
        Toast.makeText(this, "答对才能解锁哦！", Toast.LENGTH_SHORT).show();
    }
}
