package com.example.wordlock;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.IBinder;

/**
 * 前台服务：监听屏幕点亮事件，点亮即弹出全屏单词锁屏页。
 */
public class LockService extends Service {
    private static final String CH = "wordlock";

    private final BroadcastReceiver screenReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (Intent.ACTION_SCREEN_ON.equals(intent.getAction())) {
                LockActivity.start(context); // 在系统锁屏之上显示
            }
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        startForeground(1, buildNotification());
        IntentFilter f = new IntentFilter(Intent.ACTION_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 33)
            registerReceiver(screenReceiver, f, Context.RECEIVER_EXPORTED);
        else
            registerReceiver(screenReceiver, f);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override public void onDestroy() {
        try { unregisterReceiver(screenReceiver); } catch (Exception ignored) {}
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    private Notification buildNotification() {
        PendingIntent pi = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(new NotificationChannel(CH, "单词锁屏服务", NotificationManager.IMPORTANCE_MIN));
            return new Notification.Builder(this, CH)
                    .setSmallIcon(android.R.drawable.ic_lock_lock)
                    .setContentTitle("单词锁屏运行中")
                    .setContentText("点亮屏幕将先完成单词测验")
                    .setContentIntent(pi)
                    .build();
        }
        return new Notification.Builder(this)
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setContentTitle("单词锁屏运行中")
                .setContentText("点亮屏幕将先完成单词测验")
                .setContentIntent(pi)
                .build();
    }
}
