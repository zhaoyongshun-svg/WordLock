package com.example.wordlock;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.SystemClock;

/**
 * 前台服务：监听屏幕点亮事件，点亮即在最上层弹出单词锁屏悬浮窗。
 * 被杀后通过 AlarmManager 自动复活。
 */
public class LockService extends Service {
    private static final String CH = "wordlock";

    private final BroadcastReceiver screenReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (Intent.ACTION_SCREEN_ON.equals(intent.getAction())) {
                LockOverlay.show(context, 5);
            }
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, buildNotification(),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(1, buildNotification());
        }
        IntentFilter f = new IntentFilter(Intent.ACTION_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 33)
            registerReceiver(screenReceiver, f, Context.RECEIVER_EXPORTED);
        else
            registerReceiver(screenReceiver, f);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    /** 用户从最近任务移除卡片时，延迟 1 秒后尝试复活 */
    @Override public void onTaskRemoved(Intent rootIntent) {
        restartWithAlarm(1000);
        super.onTaskRemoved(rootIntent);
    }

    /** 服务被销毁（被杀）时，延迟 2 秒后尝试复活 */
    @Override public void onDestroy() {
        try { unregisterReceiver(screenReceiver); } catch (Exception ignored) {}
        LockOverlay.dismiss();
        restartWithAlarm(2000);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    private void restartWithAlarm(long delayMs) {
        try {
            AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            Intent i = new Intent(this, LockService.class);
            int flags = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
            PendingIntent pi = PendingIntent.getService(this, 0, i, flags);
            long trigger = SystemClock.elapsedRealtime() + delayMs;
            if (Build.VERSION.SDK_INT >= 23)
                am.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, trigger, pi);
            else
                am.setExact(AlarmManager.ELAPSED_REALTIME_WAKEUP, trigger, pi);
        } catch (Exception ignored) {}
    }

    private Notification buildNotification() {
        PendingIntent pi = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(new NotificationChannel(CH, "单词锁屏服务", NotificationManager.IMPORTANCE_MIN));
            return new Notification.Builder(this, CH)
                    .setSmallIcon(android.R.drawable.ic_lock_lock)
                    .setContentTitle("单词锁屏运行中")
                    .setContentText("点亮屏幕将先完成 5 道单词测验")
                    .setContentIntent(pi)
                    .build();
        }
        return new Notification.Builder(this)
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setContentTitle("单词锁屏运行中")
                .setContentText("点亮屏幕将先完成 5 道单词测验")
                .setContentIntent(pi)
                .build();
    }
}
