package com.example.wordlock;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

/**
 * 开机自动启动锁屏服务（需系统在设置中允许本应用「自启动」）。
 */
public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;
        boolean enabled = context.getSharedPreferences("cfg", Context.MODE_PRIVATE)
                .getBoolean("service_enabled", false);
        if (!enabled) return;
        start(context);
        new Handler(Looper.getMainLooper()).postDelayed(() -> start(context), 5000);
    }

    private void start(Context context) {
        try {
            Intent i = new Intent(context, LockService.class);
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i);
            else context.startService(i);
        } catch (Exception ignored) {}
    }
}
