package com.example.wordlock;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class WordDbHelper extends SQLiteOpenHelper {
    private static final String DB = "words.db";
    private static WordDbHelper instance;

    public static synchronized WordDbHelper get(Context c) {
        if (instance == null) instance = new WordDbHelper(c.getApplicationContext());
        return instance;
    }

    private WordDbHelper(Context c) { super(c, DB, null, 1); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE words(id INTEGER PRIMARY KEY AUTOINCREMENT, word TEXT, meaning TEXT)");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int o, int n) {
        db.execSQL("DROP TABLE IF EXISTS words"); onCreate(db);
    }

    public long addWord(String word, String meaning) {
        ContentValues v = new ContentValues();
        v.put("word", word.trim()); v.put("meaning", meaning.trim());
        return getWritableDatabase().insert("words", null, v);
    }

    /** 导入一行 "单词,释义"，重复单词自动跳过，返回是否新增 */
    public boolean importLine(String line) {
        String[] p = line.split("[,\t]", 2);
        if (p.length < 2) return false;
        String w = p[0].trim(), m = p[1].trim();
        if (w.isEmpty() || m.isEmpty()) return false;
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT id FROM words WHERE word=?", new String[]{w});
        boolean exists = c.moveToFirst(); c.close();
        if (exists) return false;
        addWord(w, m); return true;
    }

    public List<Word> allWords() {
        List<Word> list = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery("SELECT id,word,meaning FROM words ORDER BY id", null);
        while (c.moveToNext()) list.add(new Word(c.getLong(0), c.getString(1), c.getString(2)));
        c.close(); return list;
    }

    public Word randomWord() {
        List<Word> all = allWords();
        if (all.isEmpty()) return null;
        return all.get(new Random().nextInt(all.size()));
    }

    public void delete(long id) {
        getWritableDatabase().delete("words", "id=?", new String[]{String.valueOf(id)});
    }

    public int count() { return allWords().size(); }
}
