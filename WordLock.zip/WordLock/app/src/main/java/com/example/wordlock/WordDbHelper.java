package com.example.wordlock;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class WordDbHelper extends SQLiteOpenHelper {
    private static final String DB = "words.db";
    private static final int VER = 2;
    private static WordDbHelper instance;

    // 艾宾浩斯复习间隔（分钟）：现在、30分钟、12小时、1天、2天、4天、7天、15天
    private static final long[] INTERVALS = {0, 30, 720, 1440, 2880, 5760, 10080, 21600};
    private static final long MIN = 60000L;

    public static synchronized WordDbHelper get(Context c) {
        if (instance == null) instance = new WordDbHelper(c.getApplicationContext());
        return instance;
    }

    private WordDbHelper(Context c) { super(c, DB, null, VER); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE words(id INTEGER PRIMARY KEY AUTOINCREMENT, word TEXT, meaning TEXT, " +
                "wrong_count INTEGER DEFAULT 0, streak INTEGER DEFAULT 0, level INTEGER DEFAULT 0, " +
                "next_review INTEGER DEFAULT 0, bookmarked INTEGER DEFAULT 0)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int o, int n) {
        try { db.execSQL("ALTER TABLE words ADD COLUMN wrong_count INTEGER DEFAULT 0"); } catch (Exception ignored) {}
        try { db.execSQL("ALTER TABLE words ADD COLUMN streak INTEGER DEFAULT 0"); } catch (Exception ignored) {}
        try { db.execSQL("ALTER TABLE words ADD COLUMN level INTEGER DEFAULT 0"); } catch (Exception ignored) {}
        try { db.execSQL("ALTER TABLE words ADD COLUMN next_review INTEGER DEFAULT 0"); } catch (Exception ignored) {}
        try { db.execSQL("ALTER TABLE words ADD COLUMN bookmarked INTEGER DEFAULT 0"); } catch (Exception ignored) {}
    }

    public long addWord(String word, String meaning) {
        ContentValues v = new ContentValues();
        v.put("word", word.trim()); v.put("meaning", meaning.trim());
        return getWritableDatabase().insert("words", null, v);
    }

    public boolean importLine(String line) {
        String[] p = line.split("[,\t]", 2);
        if (p.length < 2) return false;
        String w = p[0].trim(), m = p[1].trim();
        if (w.isEmpty() || m.isEmpty()) return false;
        Cursor c = getReadableDatabase().rawQuery("SELECT id FROM words WHERE word=?", new String[]{w});
        boolean exists = c.moveToFirst(); c.close();
        if (exists) return false;
        addWord(w, m); return true;
    }

    public List<Word> allWords() {
        List<Word> list = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT id,word,meaning,wrong_count,streak,level,next_review,bookmarked FROM words ORDER BY id", null);
        while (c.moveToNext()) list.add(new Word(c.getLong(0), c.getString(1), c.getString(2),
                c.getInt(3), c.getInt(4), c.getInt(5), c.getLong(6), c.getInt(7)));
        c.close(); return list;
    }

    public void delete(long id) {
        getWritableDatabase().delete("words", "id=?", new String[]{String.valueOf(id)});
    }

    public int count() { return allWords().size(); }
    public int bookmarkedCount() {
        Cursor c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM words WHERE bookmarked=1", null);
        int n = c.moveToFirst() ? c.getInt(0) : 0; c.close(); return n;
    }
    public int dueCount() {
        Cursor c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM words WHERE next_review<=?",
                new String[]{String.valueOf(System.currentTimeMillis())});
        int n = c.moveToFirst() ? c.getInt(0) : 0; c.close(); return n;
    }

    /**
     * 艾宾浩斯选词：优先出到期的词；到期词里有重点词则只出重点词；
     * 都没有到期则随机。reviewOnly=true 时只出重点词（可为空）。
     */
    public Word nextQuizWord(boolean reviewOnly) {
        long now = System.currentTimeMillis();
        List<Word> all = allWords();
        if (all.isEmpty()) return null;
        if (reviewOnly) {
            List<Word> b = new ArrayList<>();
            for (Word w : all) if (w.bookmarked == 1) b.add(w);
            return b.isEmpty() ? null : b.get(new Random().nextInt(b.size()));
        }
        List<Word> due = new ArrayList<>();
        for (Word w : all) if (w.nextReview <= now) due.add(w);
        List<Word> pool = due.isEmpty() ? all : due;
        List<Word> pri = new ArrayList<>();
        for (Word w : pool) if (w.bookmarked == 1) pri.add(w);
        if (!pri.isEmpty()) pool = pri;
        return pool.get(new Random().nextInt(pool.size()));
    }

    /** 答错：记一次错、加入重点、10分钟后重考 */
    public void onWrong(Word w) {
        w.wrongCount++; w.streak = 0; w.bookmarked = 1; w.level = 0;
        w.nextReview = System.currentTimeMillis() + 10 * MIN;
        ContentValues v = new ContentValues();
        v.put("wrong_count", w.wrongCount); v.put("streak", 0);
        v.put("level", 0); v.put("bookmarked", 1); v.put("next_review", w.nextReview);
        getWritableDatabase().update("words", v, "id=?", new String[]{String.valueOf(w.id)});
    }

    /** 答对：连对2次移出重点，进入下一复习阶段 */
    public void onCorrect(Word w) {
        w.streak++;
        if (w.streak >= 2) w.bookmarked = 0;
        w.level = Math.min(w.level + 1, INTERVALS.length - 1);
        w.nextReview = System.currentTimeMillis() + INTERVALS[w.level] * MIN;
        ContentValues v = new ContentValues();
        v.put("streak", w.streak); v.put("level", w.level);
        v.put("bookmarked", w.bookmarked); v.put("next_review", w.nextReview);
        getWritableDatabase().update("words", v, "id=?", new String[]{String.valueOf(w.id)});
    }

    public void resetProgress() {
        getWritableDatabase().execSQL("UPDATE words SET wrong_count=0, streak=0, level=0, next_review=0, bookmarked=0");
    }
}
