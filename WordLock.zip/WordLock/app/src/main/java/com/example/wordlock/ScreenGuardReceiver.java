package com.example.wordlock;

import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.util.List;

/**
 * 屏幕点亮时自检：如果 LockService 被杀了，立即重新拉起。
 */
public class ScreenGuardReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_SCREEN_ON.equals(intent.getAction())) {
            boolean enabled = context.getSharedPreferences("cfg", Context.MODE_PRIVATE)
                    .getBoolean("service_enabled", false);
            if (!enabled) return;
            if (!isServiceRunning(context, LockService.class)) {
                try {
                    Intent i = new Intent(context, LockService.class);
                    if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i);
                    else context.startService(i);
                } catch (Exception ignored) {}
            }
            LockOverlay.show(context, 5);
        }
    }

    private boolean isServiceRunning(Context c, Class<?> cls) {
        ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningServiceInfo> list = am.getRunningServices(Integer.MAX_VALUE);
        for (ActivityManager.RunningServiceInfo info : list) {
            if (cls.getName().equals(info.service.getClassName())) return true;
        }
        return false;
    }
}
