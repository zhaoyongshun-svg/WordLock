package com.example.wordlock;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.os.Build;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 悬浮窗单词锁屏：显示在所有界面（包括系统锁屏）之上，
 * 答对 requiredCorrect 道题才能关闭。
 * 支持四选一 / 拼写默写两种模式，按艾宾浩斯曲线出题。
 */
public class LockOverlay {
    private static View root;
    private static WindowManager wm;
    private static WordDbHelper db;
    private static Word answer;
    private static int correctCount = 0;
    private static int required = 5;
    private static Context appContext;
    private static SharedPreferences prefs;

    public static boolean isShowing() { return root != null; }

    public static void show(Context c) { show(c, 5); }

    public static void show(Context c, int requiredCorrect) {
        appContext = c.getApplicationContext();
        if (root != null) return;
        prefs = appContext.getSharedPreferences("cfg", Context.MODE_PRIVATE);
        boolean spell = isSpellMode();
        required = requiredCorrect;
        correctCount = 0;
        wm = (WindowManager) appContext.getSystemService(Context.WINDOW_SERVICE);
        db = WordDbHelper.get(appContext);
        root = LayoutInflater.from(appContext).inflate(R.layout.activity_lock, null);

        int flags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
        if (!spell) flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE; // 拼写模式需要焦点弹键盘

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                flags, PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;

        // 拦截返回键，防止绕过
        root.setFocusableInTouchMode(true);
        root.setOnKeyListener((v, keyCode, e) -> {
            if (keyCode == KeyEvent.KEYCODE_BACK) {
                Toast.makeText(appContext, "答对 " + required + " 题才能解锁哦！", Toast.LENGTH_SHORT).show();
                return true;
            }
            return false;
        });

        root.findViewById(R.id.btnSkip).setOnClickListener(v ->
                Toast.makeText(appContext, "答对 " + required + " 题才能解锁哦！", Toast.LENGTH_SHORT).show());
        wm.addView(root, lp);
        newQuiz();
    }

    private static boolean isSpellMode() {
        return "spell".equals(prefs.getString("mode", "choice"));
    }

    private static void newQuiz() {
        boolean spell = isSpellMode();
        boolean reviewOnly = prefs.getBoolean("review_only", false);
        answer = db.nextQuizWord(reviewOnly);
        if (answer == null && reviewOnly) {
            answer = db.nextQuizWord(false);
            if (answer != null)
                Toast.makeText(appContext, "重点词库为空，已切换为正常出题", Toast.LENGTH_SHORT).show();
        }

        View etSpell = root.findViewById(R.id.etSpell);
        View btnSubmit = root.findViewById(R.id.btnSubmit);
        etSpell.setVisibility(spell ? View.VISIBLE : View.GONE);
        btnSubmit.setVisibility(spell ? View.VISIBLE : View.GONE);

        TextView tvMeaning = root.findViewById(R.id.tvMeaning);
        TextView tvWrong = root.findViewById(R.id.tvWrong);
        if (answer == null) {
            tvMeaning.setText("词库为空\n请先在主界面导入单词");
            return;
        }
        tvMeaning.setText(answer.meaning);
        tvWrong.setText("已答对 " + correctCount + " / " + required + " 题");

        if (spell) {
            EditText et = (EditText) etSpell;
            et.setText("");
            String w = answer.word;
            tvWrong.setText("已答对 " + correctCount + " / " + required + " 题 · 提示：" + w.charAt(0)
                    + " 开头，共 " + w.length() + " 个字母");
            btnSubmit.setOnClickListener(v -> checkSpell(et.getText().toString()));
            et.setOnEditorActionListener((v, actionId, event) -> {
                checkSpell(et.getText().toString());
                return true;
            });
            et.post(() -> {
                et.requestFocus();
                InputMethodManager imm = (InputMethodManager)
                        appContext.getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) imm.showSoftInput(et, InputMethodManager.SHOW_IMPLICIT);
            });
        }

        List<Word> all = db.allWords();
        List<Word> options = new ArrayList<>();
        options.add(answer);
        List<Word> pool = new ArrayList<>(all);
        for (int i = pool.size() - 1; i >= 0; i--) if (pool.get(i).id == answer.id) pool.remove(i);
        Collections.shuffle(pool);
        for (int i = 0; i < Math.min(3, pool.size()); i++) options.add(pool.get(i));
        Collections.shuffle(options);

        int[] btnIds = {R.id.opt0, R.id.opt1, R.id.opt2, R.id.opt3};
        for (int i = 0; i < btnIds.length; i++) {
            Button btn = root.findViewById(btnIds[i]);
            if (!spell && i < options.size()) {
                final Word w = options.get(i);
                btn.setText(w.word);
                btn.setVisibility(View.VISIBLE);
                btn.setOnClickListener(v -> onAnswer(w));
            } else {
                btn.setVisibility(View.GONE);
            }
        }
    }

    private static void checkSpell(String input) {
        if (answer == null) return;
        if (input != null && input.trim().equalsIgnoreCase(answer.word.trim())) {
            db.onCorrect(answer);
            handleCorrect();
        } else {
            db.onWrong(answer);
            Toast.makeText(appContext, "❌ 正确拼写：" + answer.word, Toast.LENGTH_LONG).show();
            newQuiz();
        }
    }

    private static void onAnswer(Word picked) {
        if (picked.id == answer.id) {
            db.onCorrect(answer);
            handleCorrect();
        } else {
            db.onWrong(answer);
            Toast.makeText(appContext, "❌ 再想想：" + picked.word + " 不对", Toast.LENGTH_SHORT).show();
            newQuiz();
        }
    }

    private static void handleCorrect() {
        correctCount++;
        if (correctCount >= required) {
            Toast.makeText(appContext, "✅ 完成！解锁", Toast.LENGTH_SHORT).show();
            dismiss();
            return;
        }
        Toast.makeText(appContext, "✅ 对了！还需 " + (required - correctCount) + " 题", Toast.LENGTH_SHORT).show();
        newQuiz();
    }

    public static void dismiss() {
        if (root != null) {
            try { wm.removeView(root); } catch (Exception ignored) {}
            root = null;
        }
    }
}
