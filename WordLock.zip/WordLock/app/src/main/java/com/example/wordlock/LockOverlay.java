package com.example.wordlock;

import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Build;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 悬浮窗单词锁屏：显示在所有界面（包括系统锁屏）之上，
 * 答对 requiredCorrect 道题才能关闭。
 */
public class LockOverlay {
    private static View root;
    private static WindowManager wm;
    private static WordDbHelper db;
    private static Word answer;
    private static int correctCount = 0;
    private static int required = 5;
    private static Context appContext;

    public static boolean isShowing() { return root != null; }

    /** 默认：答对 5 题解锁 */
    public static void show(Context c) { show(c, 5); }

    public static void show(Context c, int requiredCorrect) {
        appContext = c.getApplicationContext();
        if (root != null) return; // 已经在显示
        required = requiredCorrect;
        correctCount = 0;
        wm = (WindowManager) appContext.getSystemService(Context.WINDOW_SERVICE);
        db = WordDbHelper.get(appContext);
        root = LayoutInflater.from(appContext).inflate(R.layout.activity_lock, null);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        root.findViewById(R.id.btnSkip).setOnClickListener(v ->
                Toast.makeText(appContext, "答对 " + required + " 题才能解锁哦！", Toast.LENGTH_SHORT).show());
        wm.addView(root, lp);
        newQuiz();
    }

    private static void newQuiz() {
        answer = db.randomWord();
        TextView tvMeaning = root.findViewById(R.id.tvMeaning);
        if (answer == null) {
            tvMeaning.setText("词库为空\n请先在主界面导入单词");
            return;
        }
        tvMeaning.setText(answer.meaning);
        ((TextView) root.findViewById(R.id.tvWrong)).setText(
                "已答对 " + correctCount + " / " + required + " 题");

        List<Word> all = db.allWords();
        List<Word> options = new ArrayList<>();
        options.add(answer);
        List<Word> pool = new ArrayList<>(all);
        for (int i = pool.size() - 1; i >= 0; i--) if (pool.get(i).id == answer.id) pool.remove(i);
        Collections.shuffle(pool);
        for (int i = 0; i < Math.min(3, pool.size()); i++) options.add(pool.get(i));
        Collections.shuffle(options);

        int[] btnIds = {R.id.opt0, R.id.opt1, R.id.opt2, R.id.opt3};
        for (int i = 0; i < btnIds.length; i++) {
            Button btn = root.findViewById(btnIds[i]);
            if (i < options.size()) {
                final Word w = options.get(i);
                btn.setText(w.word);
                btn.setVisibility(View.VISIBLE);
                btn.setOnClickListener(v -> onAnswer(w));
            } else {
                btn.setVisibility(View.GONE);
            }
        }
    }

    private static void onAnswer(Word picked) {
        if (picked.id == answer.id) {
            correctCount++;
            if (correctCount >= required) {
                Toast.makeText(appContext, "✅ 完成！解锁", Toast.LENGTH_SHORT).show();
                dismiss();
                return;
            }
            Toast.makeText(appContext,
                    "✅ 对了！还需 " + (required - correctCount) + " 题", Toast.LENGTH_SHORT).show();
            newQuiz();
        } else {
            Toast.makeText(appContext, "❌ 再想想：" + picked.word + " 不对", Toast.LENGTH_SHORT).show();
            newQuiz();
        }
    }

    public static void dismiss() {
        if (root != null) {
            try { wm.removeView(root); } catch (Exception ignored) {}
            root = null;
        }
    }
}
