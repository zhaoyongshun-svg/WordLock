package com.example.wordlock;

public class Word {
    public long id;
    public String word;
    public String meaning;
    public Word(long id, String word, String meaning) {
        this.id = id; this.word = word; this.meaning = meaning;
    }
}
