package com.example.wordlock;

public class Word {
    public long id;
    public String word;
    public String meaning;
    public int wrongCount;   // 累计答错次数
    public int streak;       // 连续答对次数
    public int level;        // 艾宾浩斯阶段 0-7
    public long nextReview;  // 下次到期时间戳
    public int bookmarked;   // 是否重点复习

    public Word(long id, String word, String meaning) {
        this(id, word, meaning, 0, 0, 0, 0, 0);
    }

    public Word(long id, String word, String meaning, int wrongCount, int streak,
                int level, long nextReview, int bookmarked) {
        this.id = id; this.word = word; this.meaning = meaning;
        this.wrongCount = wrongCount; this.streak = streak; this.level = level;
        this.nextReview = nextReview; this.bookmarked = bookmarked;
    }
}
