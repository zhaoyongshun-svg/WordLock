package com.example.wordlock;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/**
 * AlarmManager 专用唤醒接收器：不受最近任务清理影响。
 */
public class AlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        boolean enabled = context.getSharedPreferences("cfg", Context.MODE_PRIVATE)
                .getBoolean("service_enabled", false);
        if (!enabled) return;
        try {
            Intent i = new Intent(context, LockService.class);
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i);
            else context.startService(i);
        } catch (Exception ignored) {}
    }
}
