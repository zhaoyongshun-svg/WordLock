package com.example.wordlock;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_IMPORT = 1;
    private WordDbHelper db;
    private List<Word> words = new ArrayList<>();
    private ArrayAdapter<String> adapter;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        db = WordDbHelper.get(this);

        findViewById(R.id.btnAdd).setOnClickListener(v -> showAddDialog());
        findViewById(R.id.btnImport).setOnClickListener(v -> pickFile());
        findViewById(R.id.btnStartLock).setOnClickListener(v -> startLock());
        findViewById(R.id.btnStopLock).setOnClickListener(v -> {
            stopService(new Intent(this, LockService.class));
            Toast.makeText(this, "锁屏背单词已停止", Toast.LENGTH_SHORT).show();
        });
        findViewById(R.id.btnPreview).setOnClickListener(v -> LockActivity.start(this));

        ListView lv = findViewById(R.id.listView);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<>());
        lv.setAdapter(adapter);
        lv.setOnItemLongClickListener((parent, view, pos, id) -> {
            new AlertDialog.Builder(this)
                .setMessage("删除该单词？")
                .setPositiveButton("删除", (d, w) -> { db.delete(words.get(pos).id); refresh(); })
                .setNegativeButton("取消", null).show();
            return true;
        });
    }

    @Override protected void onResume() { super.onResume(); refresh(); }

    private void refresh() {
        words = db.allWords();
        List<String> lines = new ArrayList<>();
        for (Word w : words) lines.add(w.word + "  —  " + w.meaning);
        adapter.clear(); adapter.addAll(lines);
        adapter.notifyDataSetChanged();
        ((TextView) findViewById(R.id.tvCount)).setText("已导入 " + db.count() + " 个单词");
    }

    private void showAddDialog() {
        View v = LayoutInflater.from(this).inflate(R.layout.dialog_add, null);
        EditText etWord = v.findViewById(R.id.etWord);
        EditText etMeaning = v.findViewById(R.id.etMeaning);
        new AlertDialog.Builder(this).setTitle("手动添加单词").setView(v)
            .setPositiveButton("保存", (d, w) -> {
                String a = etWord.getText().toString(), b = etMeaning.getText().toString();
                if (!a.trim().isEmpty() && !b.trim().isEmpty()) { db.addWord(a, b); refresh(); }
            }).setNegativeButton("取消", null).show();
    }

    private void pickFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"text/csv", "text/plain", "text/tab-separated-values"});
        startActivityForResult(i, REQ_IMPORT);
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_IMPORT && res == RESULT_OK && data != null) importFrom(data.getData());
    }

    private void importFrom(Uri uri) {
        int added = 0;
        try (InputStream is = getContentResolver().openInputStream(uri);
             BufferedReader br = new BufferedReader(new InputStreamReader(is))) {
            String line;
            while ((line = br.readLine()) != null) if (db.importLine(line)) added++;
        } catch (Exception e) {
            Toast.makeText(this, "导入失败: " + e.getMessage(), Toast.LENGTH_LONG).show(); return;
        }
        refresh();
        Toast.makeText(this, "导入完成，新增 " + added + " 个单词", Toast.LENGTH_LONG).show();
    }

    private void startLock() {
        if (db.count() == 0) {
            Toast.makeText(this, "请先导入或添加单词", Toast.LENGTH_SHORT).show(); return;
        }
        Intent i = new Intent(this, LockService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        Toast.makeText(this, "锁屏背单词已开启：点亮屏幕即弹出单词测验", Toast.LENGTH_LONG).show();
        finish();
    }
}
