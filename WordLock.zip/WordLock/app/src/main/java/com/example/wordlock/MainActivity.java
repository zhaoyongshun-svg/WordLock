package com.example.wordlock;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_IMPORT = 1;
    /** 停止服务密码，可自行修改 */
    private static final String STOP_PASSWORD = "26025233zys....";
    private WordDbHelper db;
    private List<Word> words = new ArrayList<>();
    private ArrayAdapter<String> adapter;
    private SharedPreferences prefs;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        db = WordDbHelper.get(this);
        prefs = getSharedPreferences("cfg", MODE_PRIVATE);

        findViewById(R.id.btnAdd).setOnClickListener(v -> showAddDialog());
        findViewById(R.id.btnImport).setOnClickListener(v -> pickFile());
        findViewById(R.id.btnMode).setOnClickListener(v -> showModeDialog());
        findViewById(R.id.btnReview).setOnClickListener(v -> toggleReview());
        findViewById(R.id.btnStartLock).setOnClickListener(v -> startLock());
        findViewById(R.id.btnStopLock).setOnClickListener(v -> showStopDialog());
        findViewById(R.id.btnPreview).setOnClickListener(v -> {
            if (!ensureOverlayPermission()) return;
            LockOverlay.show(this, 1);
        });

        // 长按统计行可清零
        findViewById(R.id.tvStats).setOnLongClickListener(v -> {
            prefs.edit().putLong("stat_answered", 0).putLong("stat_correct", 0).apply();
            refresh();
            Toast.makeText(this, "答题统计已清零", Toast.LENGTH_SHORT).show();
            return true;
        });

        ListView lv = findViewById(R.id.listView);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<>());
        lv.setAdapter(adapter);
        lv.setOnItemLongClickListener((parent, view, pos, id) -> {
            final Word w = words.get(pos);
            String[] opts = w.bookmarked == 1
                    ? new String[]{"删除该单词", "取消重点标记"}
                    : new String[]{"删除该单词", "标为重点"};
            new AlertDialog.Builder(this).setTitle(w.word)
                .setItems(opts, (d, which) -> {
                    if (which == 0) {
                        db.delete(w.id); refresh();
                    } else {
                        db.onWrong(w); refresh();
                        Toast.makeText(this, "已更新重点标记", Toast.LENGTH_SHORT).show();
                    }
                }).setNegativeButton("取消", null).show();
            return true;
        });
    }

    @Override protected void onResume() { super.onResume(); refresh(); }

    private void refresh() {
        words = db.allWords();
        List<String> lines = new ArrayList<>();
        for (Word w : words) {
            String flag = w.bookmarked == 1 ? "★ " : "";
            String stat = w.wrongCount > 0 ? "  (错" + w.wrongCount + ")" : "";
            lines.add(flag + w.word + "  —  " + w.meaning + stat);
        }
        adapter.clear(); adapter.addAll(lines);
        adapter.notifyDataSetChanged();
        ((TextView) findViewById(R.id.tvCount)).setText(
                "已导入 " + db.count() + " 词 | 到期 " + db.dueCount() + " | 重点 " + db.bookmarkedCount());

        // 答题统计
        long answered = prefs.getLong("stat_answered", 0);
        long correct = prefs.getLong("stat_correct", 0);
        long wrong = answered - correct;
        TextView tvStats = findViewById(R.id.tvStats);
        if (answered == 0) {
            tvStats.setText("暂无答题记录（长按可清零）");
        } else {
            tvStats.setText(String.format(Locale.getDefault(),
                    "累计答题 %d 次 · 正确 %d（%.0f%%）· 错误 %d（%.0f%%）  长按清零",
                    answered, correct, 100.0 * correct / answered,
                    wrong, 100.0 * wrong / answered));
        }

        boolean spell = "spell".equals(prefs.getString("mode", "choice"));
        ((Button) findViewById(R.id.btnMode)).setText(spell ? "模式：拼写默写" : "模式：四选一");
        boolean review = prefs.getBoolean("review_only", false);
        ((Button) findViewById(R.id.btnReview)).setText(review ? "重点复习：开" : "重点复习：关");
    }

    private void showModeDialog() {
        String[] items = {"四选一（看释义选单词）", "拼写默写（看释义写单词）"};
        int checked = "spell".equals(prefs.getString("mode", "choice")) ? 1 : 0;
        new AlertDialog.Builder(this).setTitle("答题模式")
            .setSingleChoiceItems(items, checked, (d, which) -> {
                prefs.edit().putString("mode", which == 1 ? "spell" : "choice").apply();
                refresh(); d.dismiss();
            }).show();
    }

    private void toggleReview() {
        boolean now = !prefs.getBoolean("review_only", false);
        prefs.edit().putBoolean("review_only", now).apply();
        refresh();
        Toast.makeText(this, now ? "只出重点单词" : "恢复正常出题", Toast.LENGTH_SHORT).show();
    }

    private void showStopDialog() {
        View v = LayoutInflater.from(this).inflate(R.layout.dialog_password, null);
        EditText et = v.findViewById(R.id.etPassword);
        new AlertDialog.Builder(this).setTitle("停止服务需要密码").setView(v)
            .setPositiveButton("确认", (d, w) -> {
                if (STOP_PASSWORD.equals(et.getText().toString().trim())) {
                    stopService(new Intent(this, LockService.class));
                    LockOverlay.dismiss();
                    Toast.makeText(this, "锁屏背单词已停止", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "密码错误，无法停止", Toast.LENGTH_SHORT).show();
                }
            }).setNegativeButton("取消", null).show();
    }

    private void showAddDialog() {
        View v = LayoutInflater.from(this).inflate(R.layout.dialog_add, null);
        EditText etWord = v.findViewById(R.id.etWord);
        EditText etMeaning = v.findViewById(R.id.etMeaning);
        new AlertDialog.Builder(this).setTitle("手动添加单词").setView(v)
            .setPositiveButton("保存", (d, w) -> {
                String a = etWord.getText().toString(), b = etMeaning.getText().toString();
                if (!a.trim().isEmpty() && !b.trim().isEmpty()) { db.addWord(a, b); refresh(); }
            }).setNegativeButton("取消", null).show();
    }

    private void pickFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_IMPORT);
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_IMPORT && res == RESULT_OK && data != null) importFrom(data.getData());
    }

    private void importFrom(Uri uri) {
        int added = 0;
        try (InputStream is = getContentResolver().openInputStream(uri);
             BufferedReader br = new BufferedReader(new InputStreamReader(is))) {
            String line;
            while ((line = br.readLine()) != null) if (db.importLine(line)) added++;
        } catch (Exception e) {
            Toast.makeText(this, "导入失败: " + e.getMessage(), Toast.LENGTH_LONG).show(); return;
        }
        refresh();
        Toast.makeText(this, "导入完成，新增 " + added + " 个单词", Toast.LENGTH_LONG).show();
    }

    private boolean ensureOverlayPermission() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "请先开启「显示在其他应用上层」权限", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
            return false;
        }
        return true;
    }

    private void startLock() {
        if (db.count() == 0) {
            Toast.makeText(this, "请先导入或添加单词", Toast.LENGTH_SHORT).show(); return;
        }
        if (!ensureOverlayPermission()) return;
        Intent i = new Intent(this, LockService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        Toast.makeText(this, "锁屏背单词已开启：点亮屏幕答对 5 题才能使用", Toast.LENGTH_LONG).show();
        finish();
    }
}
